%% Copyright (C) 1990, Ellemtel Telecommunications Systems Laboratories
%% File    : lists.erl
%% Author  : Joe Armstrong, Robert Virding
%% Purpose : Basic lists processing functions.

-module(lists).

-export([member/2, append/2, append/1, reverse/1, reverse/2,
	 nth/2, nthtail/2, prefix/2, suffix/2, last/1, 
	 seq/2, sum/1, duplicate/2, min/1, max/1, sublist/3,
	 delete/2, sort/1, merge/2, concat/1,
	 flatten/1, flatten/2, flat_length/1,
	 keymember/3, keysearch/3, keydelete/3, keyreplace/4,
	 keysort/2, keymerge/3, keymap/3, keymap/4]).

-export([map/3,foldl/4,foldr/4,zf/3]).

%% member(X, L) -> (true | false)
%%  test if X is a member of the list L

member(X, [X|_]) ->
	true;
member(X, [_|Y]) ->
	member(X, Y);
member(X, []) ->
	false.

%% append(X, Y) appends lists X and Y

append(X,Y) -> erlang:append(X, Y).  %% A BIF at last !!!

%%append([H|T], Z) ->
%%	[H|append(T, Z)];
%%append([], X) ->
%% 	X.

%% append(L) appends the list of lists L

append([E]) ->
    E;
append([H|T]) ->
    append(H, append(T));
append([]) ->
    [].

%% reverse(L) reverse all elements in the list L

reverse(X) ->
    reverse(X, []).

reverse([H|T], Y) ->
    reverse(T, [H|Y]);
reverse([], X) ->
    X.

%% nth(N, L) returns the N`th element of the list L
%% nthtail(N, L) returns the N`th tail of the list L

nth(1, [H|T]) ->
    H;
nth(N, [_|T]) when N > 1 ->
    nth(N - 1, T).

nthtail(1, [H|T]) ->
    T;
nthtail(N, [H|T]) when N > 1 ->
    nthtail(N - 1, T);
nthtail(0, L) when list(L) ->
    L.

%% prefix(Prefix, List) -> (true | false)

prefix([X|PreTail], [X|Tail]) ->
    prefix(PreTail, Tail);
prefix([], List) ->
    true;
prefix(_,_) ->
    false.


%% suffix(Suffix, List) -> (true | false)

suffix(Suffix, Suffix) ->
    true;
suffix(Suffix, [_|Tail]) ->
    suffix(Suffix, Tail);
suffix(Suffix, []) ->
    false.

%% last(List) returns the last element in a list.

last([E]) ->
    E;
last([E|Es]) ->
    last(Es).

%% seq(Min, Max) -> [Min,Min+1, ..., Max]
%%  returns the sequence Min..Max
%%  Min <= Max and Min and Max must be integers

seq(Min, Max) when integer(Min), integer(Max), Min =< Max -> 
    seq(Max, Min, []).

seq(Min, Min, L) -> [Min|L];
seq(Max, Min, L) -> seq(Max-1, Min, [Max|L]).

%% sum(L) suns the sum of the elements in L

sum(L)          -> sum(L, 0).
sum([H|T], Sum) -> sum(T, Sum + H);
sum([], Sum)    -> Sum.

%% duplicate(N, X) -> [X,X,X,.....,X]  (N times)
%%   return N copies of X

duplicate(N, X) when integer(N), N >= 0 -> duplicate(N, X, []).

duplicate(0, _, L) -> L;
duplicate(N, X, L) -> duplicate(N-1, X, [X|L]).


%% min(L) -> returns the minimum element of the list L

min([H|T]) -> min(T, H).

min([H|T], Min) when H < Min -> min(T, H);
min([_|T], Min)              -> min(T, Min);
min([],    Min)              -> Min. 

%% max(L) -> returns the maximum element of the list L

max([H|T]) -> max(T, H).

max([H|T], Max) when H > Max -> max(T, H);
max([_|T], Max)              -> max(T, Max);
max([],    Max)              -> Max.

%% sublist(List, Start, Length)
%%  Returns the sub-list starting at Start of length Length.

sublist(List, S, L) when L >= 0 ->
    sublist(nthtail(S-1, List), L).

sublist([H|T], L) when L > 0 ->
    [H|sublist(T, L-1)];
sublist(List, L) ->
    [].

%% delete(Item, List) -> List'
%%  Delete the first occurance of Item from the list L.

delete(Item, [Item|Rest]) ->
    Rest;
delete(Item, [H|Rest]) ->
    [H|delete(Item, Rest)];
delete(Item, []) ->
    [].

%% sort(L) -> sorts the list L

sort([X]) -> [X];
sort([])  -> [];
sort(X)   -> split_and_sort(X, [], []).

split_and_sort([A,B|T], X, Y) ->
    split_and_sort(T, [A|X], [B|Y]);
split_and_sort([H], X, Y) ->
    split_and_sort([], [H|X], Y);
split_and_sort([], X, Y) ->
    merge(sort(X), sort(Y), []).

%% merge(X, Y) -> L
%%  merges two sorted lists X and Y

merge(X, Y) -> merge(X, Y, []).

merge([H1|T1], [H2|T2], L) when H1 < H2 ->
    merge(T1,[H2|T2], [H1|L]);
merge(T1, [H2|T2], L) ->
    merge(T1, T2, [H2|L]);
merge([H|T], T2, L) ->
    merge(T, T2, [H|L]);
merge([], [], L) ->
    reverse(L).

%% concat(L) concatinate the list representation of the elements
%%  in L - the elements in L can be atoms, integers of strings.
%%  Returns a list of characters.

concat([H|T]) ->
    append(thing_to_list(H), concat(T));
concat([]) ->
    [].

thing_to_list(X) when integer(X) -> integer_to_list(X);
thing_to_list(X) when float(X)	 -> float_to_list(X);
thing_to_list(X) when atom(X)	 -> atom_to_list(X);
thing_to_list(X) when list(X)	 -> X.		%Assumed to be a string

%% flatten(List)
%% flatten(List, Tail)
%%  Flatten a list, adding optional tail.

flatten(List) ->
    flatten(List, [], []).

flatten(List, Tail) ->
    flatten(List, [], Tail).

flatten([H|T], Cont, Tail) when list(H) ->
    flatten(H, [T|Cont], Tail);
flatten([H|T], Cont, Tail) ->
    [H|flatten(T, Cont, Tail)];
flatten([], [H|Cont], Tail) ->
    flatten(H, Cont, Tail);
flatten([], [], Tail) ->
    Tail.

%% flat_length(List)
%%  Calculate the length of a list of lists.

flat_length(List) ->
    flat_length(List, 0).

flat_length([H|T], L) when list(H) ->
    flat_length(H, flat_length(T, L));
flat_length([H|T], L) ->
    flat_length(T, L + 1);
flat_length([], L) ->
    L.

%% keymember(Key, Index, TupleList)
%% keysearch(Key, Index, TupleList)
%% keydelete(Key, Index, TupleList)
%% keyreplace(Key, Index, TupleList, NewTuple)
%% keysort(Index, TupleList)
%% keymerge(Index, SortedTupleList1, SortedTupleList2)

keymember(Key, N, [T|Ts]) when element(N, T) == Key ->
    true;
keymember(Key, N, [T|Ts]) ->
    keymember(Key, N, Ts);
keymember(Key, N, []) ->
    false.

keysearch(Key, N, [H|T]) when element(N, H) == Key ->
    {value, H};
keysearch(Key, N, [H|T]) ->
    keysearch(Key, N, T);
keysearch(Key, N, []) ->
    false.

keydelete(Key, N, [H|T]) when element(N, H) == Key ->
    T;
keydelete(Key, N, [H|T]) ->
    [H|keydelete(Key, N, T)];
keydelete(Key, N, []) ->
    [].

keyreplace(Key,Pos,[],New) -> [];
keyreplace(Key,Pos,[Tup|Tail],New) when element(Pos,Tup) == Key ->
    [New | Tail];
keyreplace(Key,Pos,[H|T],New) ->
    [H | keyreplace(Key,Pos,T,New)].

keysort(Index, [X]) -> [X];
keysort(Index, [])  -> [];
keysort(Index, X)   -> split_and_keysort(X, [], [], Index).

split_and_keysort([A,B|T], X, Y, Index) ->
    split_and_keysort(T, [A|X], [B|Y], Index);
split_and_keysort([H], X, Y, Index) ->
    split_and_keysort([], [H|X], Y, Index);
split_and_keysort([], X, Y, Index) ->
    keymerge(Index, keysort(Index, X), keysort(Index, Y), []).

keymerge(Index, X, Y) -> keymerge(Index, X, Y, []).

keymerge(I, [H1|T1], [H2|T2], L) when element(I, H1) < element(I, H2) ->
    keymerge(I, T1,[H2|T2], [H1|L]);
keymerge(Index, T1, [H2|T2], L) ->
    keymerge(Index,T1, T2, [H2|L]);
keymerge(Index,[H|T], T2, L) ->
    keymerge(Index,T, T2, [H|L]);
keymerge(Index, [], [], L) ->
    reverse(L).

keymap({Mod, Func}, Pos, List) ->
   keymap({Mod, Func}, Pos, List, []).
keymap( _, _ , [], _) -> [];
keymap({Mod, Func}, Pos, [Tup| Tail], ExtraArgs) ->
   [setelement(Pos, Tup, apply({Mod, Func}, [element(Pos, Tup)| ExtraArgs]))|
    keymap({Mod, Func}, Pos, Tail, ExtraArgs)].

%% map(Function, ExtraArgs, List)
%% foldl(Function, ExtraArgs, Last, List)
%% foldr(Function, ExtraArgs, List, Last)
%% zf(Function, ExtraArgs, List)
%%  These are Erlang versions of some standard higher order functions
%%  for list programming. Function here is a tuple {Module,Name} and
%%  we use apply/2 to evaluate. ExtraArgs are a list of extra arguments
%%  to each call. The argument order for foldl and foldr are meant
%%  to indicate their relative positions in the call to the function.
%%  zf/3 is a hack for the extraction part of ZF (Zermelo Frankel)
%%  expressions or list comprehensions.
%%
%%  All of these look much nicer in a language with true higher-order
%%  functions!


map(F, As, [Hd|Tail]) ->
    [apply(F, [Hd|As])|map(F, As, Tail)];
map(F, As, []) -> [].

foldl(F, As, Last, [Hd|Tail]) ->
    foldl(F, As, apply(F, [Last,Hd|As]), Tail);
foldl(F, As, Last, []) ->
    Last.

foldr(F, As, [Hd|Tail], Last) ->
    apply(F, [Hd,foldr(F, As, Last, Tail)|As]);
foldr(F, As, [], Last) ->
    Last.

zf(F, As, [H|T]) ->
    case apply(F, [H|As]) of
	true ->
	    [H|zf(F, As, T)];
	{true,Val} ->
	    [Val|zf(F, As, T)];
	false ->
	    zf(F, As, T)
    end;
zf(F, As, []) ->
    [].
