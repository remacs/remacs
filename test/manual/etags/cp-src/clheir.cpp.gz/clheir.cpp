/* ======================================================================= */
/*                                CLHEIR.CPP                               */
/* ======================================================================= */

#include "assert.h"
#include "iostream.h"
#include "clheir.h"

const int max_num_generic_objects = 5000;
generic_object * object_registry[max_num_generic_objects];

void init_registry(void)
    {
    int i;

    for (i = 0; i < max_num_generic_objects; i++) object_registry[i] = NULL;
    }

void step_everybody(void)
    {
    int i;

    for (i = 0; i < max_num_generic_objects; i++)
        if (object_registry[i] != NULL)
            object_registry[i]->compute_next_state();
    for (i = 0; i < max_num_generic_objects; i++)
        if (object_registry[i] != NULL)
            object_registry[i]->step();
    }

void discrete_location::clear_neighbors(void)
    {
    for (int i = 0; i < max_num_directions; i++) neighbors[i] = NULL;
    }

generic_object::generic_object(void)
    {
    int i;

    for (i = 0;
        i < max_num_generic_objects && object_registry[i] != NULL;
        i++);
    assert(i < max_num_generic_objects);
    where_in_registry = i;
    object_registry[where_in_registry] = this;
    }

generic_object::~generic_object(void)
    {
    object_registry[where_in_registry] = NULL;
    }

void agent::move(int direction)
    {

    }
